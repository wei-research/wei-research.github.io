!#/bin/bash

#sed -e "s/^ \+//g" -e "s/^\(-\?[[:digit:]]\+\.[[:digit:]]\{7\}\)\([[:digit:]]\+\)/\1/g" nsw.geojson | tr '\n' ' '> nsw.compact.geojson

echo this is the command to strip the geojson file to a more managable file size
