var lgaLat = new Array();
var lgaLng = new Array();
var lgaNames = new Array();
var lgaColor = new Array();

lgaNames[0] = 'Fairfield';
lgaLat[0] = -33.850457;
lgaLng[0] = 150.961124;
lgaColor[0] = 1;

lgaNames[1] = 'Blacktown';
lgaLat[1] = -33.770184;
lgaLng[1] = 150.908501;
lgaColor[1] = 2;

lgaNames[2] = 'Parramatta';
lgaLat[2] = -33.886166;
lgaLng[2] = 151.139472;
lgaColor[2] = 3;

lgaNames[3] = 'Newcastle';
lgaLat[3] = -32.926357;
lgaLng[3] = 151.78122;
lgaColor[3] = 4;

lgaNames[4] = 'Bankstown';
lgaLat[4] = -33.907417;
lgaLng[4] = 151.024581;
lgaColor[4] = 5;

lgaNames[5] = 'Sydney City';
lgaLat[5] = -33.794883;
lgaLng[5] = 151.268071;
lgaColor[5] = 6;

lgaNames[6] = 'Lake Macquarie';
lgaLat[6] = -33.777139;
lgaLng[6] = 151.120702;
lgaColor[6] = 7;

lgaNames[7] = 'Liverpool';
lgaLat[7] = -33.888327;
lgaLng[7] = 151.103632;
lgaColor[7] = 8;

lgaNames[8] = 'Wollongong';
lgaLat[8] = -34.425878;
lgaLng[8] = 150.899818;
lgaColor[8] = 0;

lgaNames[9] = 'Campbelltown';
lgaLat[9] = -34.067441;
lgaLng[9] = 150.812522;
lgaColor[9] = 1;

lgaNames[10] = 'Holroyd';
lgaLat[10] = -33.829836;
lgaLng[10] = 150.993334;
lgaColor[10] = 2;

lgaNames[11] = 'Sutherland';
lgaLat[11] = -34.015705;
lgaLng[11] = 151.0622;
lgaColor[11] = 3;

lgaNames[12] = 'Hawkesbury';
lgaLat[12] = -33.5305;
lgaLng[12] = 151.2419;
lgaColor[12] = 4;

lgaNames[13] = 'Cessnock';
lgaLat[13] = -32.832943;
lgaLng[13] = 151.353993;
lgaColor[13] = 5;

lgaNames[14] = 'Penrith';
lgaLat[14] = -33.744073;
lgaLng[14] = 150.69602;
lgaColor[14] = 6;

lgaNames[15] = 'Wingecarribee';
lgaLat[15] = -34.623;
lgaLng[15] = 150.408;
lgaColor[15] = 7;

lgaNames[16] = 'Blue Mountains';
lgaLat[16] = -33.6506;
lgaLng[16] = 150.4428;
lgaColor[16] = 8;

lgaNames[17] = 'Muswellbrook';
lgaLat[17] = -32.263323;
lgaLng[17] = 150.888821;
lgaColor[17] = 0;

lgaNames[18] = 'Wyong';
lgaLat[18] = -33.28348;
lgaLng[18] = 151.422404;
lgaColor[18] = 1;

lgaNames[19] = 'Shoalhaven';
lgaLat[19] = -34.851;
lgaLng[19] = 150.7448;
lgaColor[19] = 2;

lgaNames[20] = 'Randwick';
lgaLat[20] = -33.913164;
lgaLng[20] = 151.241993;
lgaColor[20] = 3;

lgaNames[21] = 'Warringah';
lgaLat[21] = -33.7531;
lgaLng[21] = 151.24;
lgaColor[21] = 4;

lgaNames[22] = 'Ryde';
lgaLat[22] = -33.761498;
lgaLng[22] = 151.137807;
lgaColor[22] = 5;

lgaNames[23] = 'Canterbury';
lgaLat[23] = -33.910848;
lgaLng[23] = 151.121145;
lgaColor[23] = 6;

lgaNames[24] = 'Hornsby';
lgaLat[24] = -33.707684;
lgaLng[24] = 151.099812;
lgaColor[24] = 7;

lgaNames[25] = 'Maitland';
lgaLat[25] = -32.734714;
lgaLng[25] = 151.558573;
lgaColor[25] = 8;

lgaNames[26] = 'Auburn';
lgaLat[26] = -33.883928;
lgaLng[26] = 151.023796;
lgaColor[26] = 0;

lgaNames[27] = 'Gosford';
lgaLat[27] = -33.426938;
lgaLng[27] = 151.341843;
lgaColor[27] = 1;

lgaNames[28] = 'Port Stephens';
lgaLat[28] = -32.6853;
lgaLng[28] = 152.034;
lgaColor[28] = 2;

lgaNames[29] = 'Coffs Harbour';
lgaLat[29] = -30.282279;
lgaLng[29] = 153.128593;
lgaColor[29] = 3;

lgaNames[30] = 'Upper Hunter';
lgaLat[30] = -31.9812;
lgaLng[30] = 150.6928;
lgaColor[30] = 4;

lgaNames[31] = 'Hurstville';
lgaLat[31] = -33.975869;
lgaLng[31] = 151.088939;
lgaColor[31] = 5;

lgaNames[32] = 'Port Macquarie-Hastings';
lgaLat[32] = -31.42106;
lgaLng[32] = 152.5192;
lgaColor[32] = 6;

lgaNames[33] = 'Marrickville';
lgaLat[33] = -33.90911;
lgaLng[33] = 151.15334;
lgaColor[33] = 7;

lgaNames[34] = 'The Hills';
lgaLat[34] = -33.7744;
lgaLng[34] = 150.9329;
lgaColor[34] = 8;

lgaNames[35] = 'Greater Taree';
lgaLat[35] = -31.80491;
lgaLng[35] = 152.2796;
lgaColor[35] = 0;

lgaNames[36] = 'Ku-Ring-Gai';
lgaLat[36] = -33.648;
lgaLng[36] = 151.1341;
lgaColor[36] = 1;

lgaNames[37] = 'Wollondilly';
lgaLat[37] = -34.2671;
lgaLng[37] = 150.6981;
lgaColor[37] = 2;

lgaNames[38] = 'Singleton';
lgaLat[38] = -32.564025;
lgaLng[38] = 151.168367;
lgaColor[38] = 3;

lgaNames[39] = 'Clarence Valley';
lgaLat[39] = -29.6915;
lgaLng[39] = 152.9324;
lgaColor[39] = 4;

lgaNames[40] = 'Kempsey';
lgaLat[40] = -31.080621;
lgaLng[40] = 152.84199;
lgaColor[40] = 5;

lgaNames[41] = 'Camden';
lgaLat[41] = -34.054599;
lgaLng[41] = 150.695678;
lgaColor[41] = 6;

lgaNames[42] = 'Tweed';
lgaLat[42] = -28.2268;
lgaLng[42] = 153.5096;
lgaColor[42] = 7;

lgaNames[43] = 'Botany Bay';
lgaLat[43] = -33.9758;
lgaLng[43] = 151.2253;
lgaColor[43] = 8;

lgaNames[44] = 'Willoughby';
lgaLat[44] = -33.801483;
lgaLng[44] = 151.1986;
lgaColor[44] = 0;

lgaNames[45] = 'North Sydney';
lgaLat[45] = -33.802837;
lgaLng[45] = 151.104935;
lgaColor[45] = 1;

lgaNames[46] = 'Great Lakes';
lgaLat[46] = -32.2002;
lgaLng[46] = 152.5206;
lgaColor[46] = 2;

lgaNames[47] = 'Dungog';
lgaLat[47] = -32.403867;
lgaLng[47] = 151.757171;
lgaColor[47] = 3;

lgaNames[48] = 'Rockdale';
lgaLat[48] = -33.952747;
lgaLng[48] = 151.137624;
lgaColor[48] = 4;

lgaNames[49] = 'Pittwater';
lgaLat[49] = -33.6162;
lgaLng[49] = 151.3062;
lgaColor[49] = 5;

lgaNames[50] = 'Lane Cove';
lgaLat[50] = -33.791875;
lgaLng[50] = 151.187955;
lgaColor[50] = 6;

lgaNames[51] = 'Byron';
lgaLat[51] = -28.6437;
lgaLng[51] = 153.6103;
lgaColor[51] = 7;

lgaNames[52] = 'Ballina';
lgaLat[52] = -28.869984;
lgaLng[52] = 153.559167;
lgaColor[52] = 8;

lgaNames[53] = 'Manly';
lgaLat[53] = -33.329799;
lgaLng[53] = 151.505125;
lgaColor[53] = 0;

lgaNames[54] = 'Waverley';
lgaLat[54] = -33.897955;
lgaLng[54] = 151.252059;
lgaColor[54] = 1;

lgaNames[55] = 'Mosman';
lgaLat[55] = -33.829077;
lgaLng[55] = 151.24409;
lgaColor[55] = 2;

lgaNames[56] = 'Lismore';
lgaLat[56] = -28.812725;
lgaLng[56] = 153.278721;
lgaColor[56] = 3;

lgaNames[57] = 'Shellharbour';
lgaLat[57] = -34.579035;
lgaLng[57] = 150.867929;
lgaColor[57] = 4;

lgaNames[58] = 'Bellingen';
lgaLat[58] = -30.452388;
lgaLng[58] = 152.898147;
lgaColor[58] = 5;

lgaNames[59] = 'Gunnedah';
lgaLat[59] = -30.978589;
lgaLng[59] = 150.255412;
lgaColor[59] = 6;

lgaNames[60] = 'Leichhardt';
lgaLat[60] = -33.883793;
lgaLng[60] = 151.157057;
lgaColor[60] = 7;

lgaNames[61] = 'Tamworth';
lgaLat[61] = -31.091743;
lgaLng[61] = 150.930821;
lgaColor[61] = 8;

lgaNames[62] = 'Nambucca';
lgaLat[62] = -30.6399;
lgaLng[62] = 152.982;
lgaColor[62] = 0;

lgaNames[63] = 'Kogarah';
lgaLat[63] = -33.963107;
lgaLng[63] = 151.133462;
lgaColor[63] = 1;

lgaNames[64] = 'Gloucester';
lgaLat[64] = -32.007036;
lgaLng[64] = 151.958362;
lgaColor[64] = 2;

lgaNames[65] = 'Hunters Hill';
lgaLat[65] = -33.83484;
lgaLng[65] = 151.154196;
lgaColor[65] = 3;

lgaNames[66] = 'Armidale Dumaresq';
lgaLat[66] = -30.514674;
lgaLng[66] = 151.665341;
lgaColor[66] = 4;

lgaNames[67] = 'Mid-Western';
lgaLat[67] = -32.589607;
lgaLng[67] = 149.584352;
lgaColor[67] = 5;

lgaNames[68] = 'Woollahra';
lgaLat[68] = -33.885795;
lgaLng[68] = 151.24413;
lgaColor[68] = 6;

lgaNames[69] = 'Ashfield';
lgaLat[69] = -34.096505;
lgaLng[69] = 150.778939;
lgaColor[69] = 7;

lgaNames[70] = 'Albury';
lgaLat[70] = -36.082137;
lgaLng[70] = 146.910174;
lgaColor[70] = 8;

lgaNames[71] = 'Wagga Wagga';
lgaLat[71] = -35.109861;
lgaLng[71] = 147.370515;
lgaColor[71] = 0;

lgaNames[72] = 'Deniliquin';
lgaLat[72] = -35.528544;
lgaLng[72] = 144.958974;
lgaColor[72] = 1;

lgaNames[73] = 'Canada Bay';
lgaLat[73] = -33.863194;
lgaLng[73] = 151.116398;
lgaColor[73] = 2;

lgaNames[74] = 'Gwydir';
lgaLat[74] = -29.867703;
lgaLng[74] = 150.572246;
lgaColor[74] = 3;

lgaNames[75] = 'Glen Innes Severn';
lgaLat[75] = -29.740071;
lgaLng[75] = 151.73701;
lgaColor[75] = 4;

lgaNames[76] = 'Richmond Valley';
lgaLat[76] = -28.865527;
lgaLng[76] = 153.047176;
lgaColor[76] = 5;

lgaNames[77] = 'Kyogle';
lgaLat[77] = -28.622384;
lgaLng[77] = 153.004112;
lgaColor[77] = 6;

lgaNames[78] = 'Moree Plains';
lgaLat[78] = -29.463069;
lgaLng[78] = 149.842589;
lgaColor[78] = 7;

lgaNames[79] = 'Bathurst';
lgaLat[79] = -33.41978;
lgaLng[79] = 149.574258;
lgaColor[79] = 8;

lgaNames[80] = 'Narrabri';
lgaLat[80] = -30.324835;
lgaLng[80] = 149.782833;
lgaColor[80] = 0;

lgaNames[81] = 'Tenterfield';
lgaLat[81] = -29.041657;
lgaLng[81] = 152.021335;
lgaColor[81] = 1;

lgaNames[82] = 'Inverell';
lgaLat[82] = -29.775667;
lgaLng[82] = 151.112928;
lgaColor[82] = 2;

lgaNames[83] = 'Burwood';
lgaLat[83] = -33.891556;
lgaLng[83] = 151.10082;
lgaColor[83] = 3;

lgaNames[84] = 'Cabonne';
lgaLat[84] = -33.091235;
lgaLng[84] = 148.867584;
lgaColor[84] = 4;

lgaNames[85] = 'Dubbo';
lgaLat[85] = -32.245192;
lgaLng[85] = 148.604212;
lgaColor[85] = 5;

lgaNames[86] = 'Griffith';
lgaLat[86] = -34.289045;
lgaLng[86] = 146.043671;
lgaColor[86] = 6;

lgaNames[87] = 'Bega Valley';
lgaLat[87] = -36.676756;
lgaLng[87] = 149.842715;
lgaColor[87] = 7;

lgaNames[88] = 'Cooma-Monaro';
lgaLat[88] = -36.235146;
lgaLng[88] = 149.127244;
lgaColor[88] = 8;

lgaNames[89] = 'Tumut';
lgaLat[89] = -35.300634;
lgaLng[89] = 148.224961;
lgaColor[89] = 0;

lgaNames[90] = 'Leeton';
lgaLat[90] = -34.5522;
lgaLng[90] = 146.406444;
lgaColor[90] = 1;

lgaNames[91] = 'Guyra';
lgaLat[91] = -30.217184;
lgaLng[91] = 151.673119;
lgaColor[91] = 2;

lgaNames[92] = 'Greater Hume';
lgaLat[92] = -35.667465;
lgaLng[92] = 147.036353;
lgaColor[92] = 3;

lgaNames[93] = 'Liverpool Plains';
lgaLat[93] = -31.503414;
lgaLng[93] = 150.680225;
lgaColor[93] = 4;

lgaNames[94] = 'Coolamon';
lgaLat[94] = -34.815539;
lgaLng[94] = 147.200085;
lgaColor[94] = 5;

lgaNames[95] = 'Walcha';
lgaLat[95] = -30.992066;
lgaLng[95] = 151.592052;
lgaColor[95] = 6;

lgaNames[96] = 'Uralla';
lgaLat[96] = -30.642829;
lgaLng[96] = 151.502566;
lgaColor[96] = 7;

lgaNames[97] = 'Young';
lgaLat[97] = -34.31341;
lgaLng[97] = 148.297921;
lgaColor[97] = 8;

lgaNames[98] = 'Corowa';
lgaLat[98] = -35.997952;
lgaLng[98] = 146.391214;
lgaColor[98] = 0;

lgaNames[99] = 'Kiama';
lgaLat[99] = -34.671676;
lgaLng[99] = 150.856703;
lgaColor[99] = 1;

lgaNames[100] = 'Bland';
lgaLat[100] = -33.994749;
lgaLng[100] = 147.678307;
lgaColor[100] = 2;

lgaNames[101] = 'Carrathool';
lgaLat[101] = -34.407182;
lgaLng[101] = 145.430787;
lgaColor[101] = 3;

lgaNames[102] = 'Cootamundra';
lgaLat[102] = -34.639089;
lgaLng[102] = 148.024671;
lgaColor[102] = 4;

lgaNames[103] = 'Lithgow';
lgaLat[103] = -33.480068;
lgaLng[103] = 150.157987;
lgaColor[103] = 5;

lgaNames[104] = 'Central Darling';
lgaLat[104] = -33.875273;
lgaLng[104] = 151.199053;
lgaColor[104] = 6;

lgaNames[105] = 'Unincorporated NSW';
lgaLat[105] = -30.977709;
lgaLng[105] = 141.554632;
lgaColor[105] = 7;

lgaNames[106] = 'Broken Hill';
lgaLat[106] = -31.959193;
lgaLng[106] = 141.466614;
lgaColor[106] = 8;

lgaNames[107] = 'Lockhart';
lgaLat[107] = -35.221085;
lgaLng[107] = 146.716343;
lgaColor[107] = 0;

lgaNames[108] = 'Berrigan';
lgaLat[108] = -35.65743;
lgaLng[108] = 145.812641;
lgaColor[108] = 1;

lgaNames[109] = 'Tumbarumba';
lgaLat[109] = -35.777459;
lgaLng[109] = 148.012861;
lgaColor[109] = 2;

lgaNames[110] = 'Conargo';
lgaLat[110] = -35.302371;
lgaLng[110] = 145.181217;
lgaColor[110] = 3;

lgaNames[111] = 'Murray';
lgaLat[111] = -35.051862;
lgaLng[111] = 143.501086;
lgaColor[111] = 4;

lgaNames[112] = 'Hay';
lgaLat[112] = -34.500508;
lgaLng[112] = 144.845099;
lgaColor[112] = 5;

lgaNames[113] = 'Junee';
lgaLat[113] = -34.870998;
lgaLng[113] = 147.584679;
lgaColor[113] = 6;

lgaNames[114] = 'Wakool';
lgaLat[114] = -35.470616;
lgaLng[114] = 144.395693;
lgaColor[114] = 7;

lgaNames[115] = 'Lachlan';
lgaLat[115] = -33.084644;
lgaLng[115] = 147.150651;
lgaColor[115] = 8;

lgaNames[116] = 'Orange';
lgaLat[116] = -33.276948;
lgaLng[116] = 149.099775;
lgaColor[116] = 0;

lgaNames[117] = 'Blayney';
lgaLat[117] = -33.532319;
lgaLng[117] = 149.255263;
lgaColor[117] = 1;

lgaNames[118] = 'Temora';
lgaLat[118] = -34.446858;
lgaLng[118] = 147.533742;
lgaColor[118] = 2;

lgaNames[119] = 'Urana';
lgaLat[119] = -35.329447;
lgaLng[119] = 146.265684;
lgaColor[119] = 3;

lgaNames[120] = 'Narrandera';
lgaLat[120] = -34.744609;
lgaLng[120] = 146.55696;
lgaColor[120] = 4;

lgaNames[121] = 'Parkes';
lgaLat[121] = -33.138326;
lgaLng[121] = 148.174166;
lgaColor[121] = 5;

lgaNames[122] = 'Gundagai';
lgaLat[122] = -35.065534;
lgaLng[122] = 148.107529;
lgaColor[122] = 6;

lgaNames[123] = 'Strathfield';
lgaLat[123] = -33.877139;
lgaLng[123] = 151.093326;
lgaColor[123] = 7;

lgaNames[124] = 'Jerilderie';
lgaLat[124] = -35.356448;
lgaLng[124] = 145.72928;
lgaColor[124] = 8;

lgaNames[125] = 'Eurobodalla';
lgaLat[125] = -36.141108;
lgaLng[125] = 149.979087;
lgaColor[125] = 0;

lgaNames[126] = 'Murrumbidgee';
lgaLat[126] = -34.568543;
lgaLng[126] = 145.998996;
lgaColor[126] = 1;

lgaNames[127] = 'Forbes';
lgaLat[127] = -33.385343;
lgaLng[127] = 148.007905;
lgaColor[127] = 2;

lgaNames[128] = 'Yass Valley';
lgaLat[128] = -34.844385;
lgaLng[128] = 148.913353;
lgaColor[128] = 3;

lgaNames[129] = 'Cowra';
lgaLat[129] = -33.83468;
lgaLng[129] = 148.691192;
lgaColor[129] = 4;

lgaNames[130] = 'Goulburn Mulwaree';
lgaLat[130] = -34.69267;
lgaLng[130] = 150.047999;
lgaColor[130] = 5;

lgaNames[131] = 'Oberon';
lgaLat[131] = -33.703856;
lgaLng[131] = 149.855484;
lgaColor[131] = 6;

lgaNames[132] = 'Gilgandra';
lgaLat[132] = -31.711715;
lgaLng[132] = 148.663131;
lgaColor[132] = 7;

lgaNames[133] = 'Queanbeyan';
lgaLat[133] = -35.354443;
lgaLng[133] = 149.232083;
lgaColor[133] = 8;

lgaNames[134] = 'Narromine';
lgaLat[134] = -32.23192;
lgaLng[134] = 148.239606;
lgaColor[134] = 0;

lgaNames[135] = 'Weddin';
lgaLat[135] = -33.894387;
lgaLng[135] = 148.159405;
lgaColor[135] = 1;

lgaNames[136] = 'Wellington';
lgaLat[136] = -32.55588;
lgaLng[136] = 148.944797;
lgaColor[136] = 2;

lgaNames[137] = 'Warrumbungle';
lgaLat[137] = -31.277554;
lgaLng[137] = 148.982041;
lgaColor[137] = 3;

lgaNames[138] = 'Bombala';
lgaLat[138] = -36.909544;
lgaLng[138] = 149.242198;
lgaColor[138] = 4;

lgaNames[139] = 'Boorowa';
lgaLat[139] = -34.438598;
lgaLng[139] = 148.716326;
lgaColor[139] = 5;

lgaNames[140] = 'Cobar';
lgaLat[140] = -31.498218;
lgaLng[140] = 145.840727;
lgaColor[140] = 6;

lgaNames[141] = 'Harden';
lgaLat[141] = -34.555033;
lgaLng[141] = 148.369635;
lgaColor[141] = 7;

lgaNames[142] = 'Balranald';
lgaLat[142] = -34.638049;
lgaLng[142] = 143.561101;
lgaColor[142] = 8;

lgaNames[143] = 'Walgett';
lgaLat[143] = -30.021558;
lgaLng[143] = 148.116684;
lgaColor[143] = 0;

lgaNames[144] = 'Wentworth';
lgaLat[144] = -34.106868;
lgaLng[144] = 141.919215;
lgaColor[144] = 1;

lgaNames[145] = 'Upper Lachlan';
lgaLat[145] = -34.457541;
lgaLng[145] = 149.471185;
lgaColor[145] = 2;

lgaNames[146] = 'Warren';
lgaLat[146] = -31.699379;
lgaLng[146] = 147.83731;
lgaColor[146] = 3;

lgaNames[147] = 'Bogan';
lgaLat[147] = -31.943157;
lgaLng[147] = 147.463241;
lgaColor[147] = 4;

lgaNames[148] = 'Snowy River';
lgaLat[148] = -36.751573;
lgaLng[148] = 148.515477;
lgaColor[148] = 5;

lgaNames[149] = 'Brewarrina';
lgaLat[149] = -29.961519;
lgaLng[149] = 146.858999;
lgaColor[149] = 6;

lgaNames[150] = 'Coonamble';
lgaLat[150] = -30.954311;
lgaLng[150] = 148.388448;
lgaColor[150] = 7;

lgaNames[151] = 'Palerang';
lgaLat[151] = -35.42774;
lgaLng[151] = 149.568117;
lgaColor[151] = 8;

lgaNames[152] = 'Bourke';
lgaLat[152] = -30.088847;
lgaLng[152] = 145.937742;
lgaColor[152] = 0;

var lgaLabels = {
	"type": "FeatureCollection",
	"features": [],
};

for (i = 0; i < 153; i++) {
	lgaLabels.features.push({
		"type": "Feature",
		"properties": {
			"name": lgaNames[i],
		},
		"geometry": {
			"type": "Point",
			"coordinates": [
				lgaLng[i],
				lgaLat[i]
			]
		}
	});

}

